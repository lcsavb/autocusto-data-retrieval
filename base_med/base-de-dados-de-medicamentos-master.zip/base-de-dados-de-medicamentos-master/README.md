# base-de-dados-de-medicamentos
Base de dados de medicamentos open-source em JSON

Para importar para MongoDB é só usar o comando mongoimport.
